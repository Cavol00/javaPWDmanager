Ciao questa sborra è stata fatta da me per la gestione delle password tramite un file presente sul pc.
Workflow:
    -Creare un file dove scrivere le password.
    -Menu che chiede cosa si vuole fare.
    -3 opzioni tra cui:
        -Leggere pwd.
        -Inserire pwd.
        -Uscire.


COSE DA RICERCARE TRA GLI APPUNTI.
Utilizzo dei file reader e writer.
Imparare come posso criptare un file di testo in java.