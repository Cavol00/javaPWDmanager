package Applicazione;
public class App {
    public static void main(String[] args){
        System.out.println("Questa applicazine è stata creata da Dario.");
        Menu.men();

    }
}
